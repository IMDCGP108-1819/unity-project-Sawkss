﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour {


    private Vector3 startPos;
    private Transform thisTransform;
    private MeshRenderer mr;
    private bool isButton;
    private bool leftjoystick;
    private string buttonName;
    private bool rightjoystick;


    // Use this for initialization
    private void Start ()
    {
        thisTransform = transform;
        startPos = thisTransform.position;
        mr = thisTransform.GetComponent<MeshRenderer>();
	}
	
	// Update is called once per frame
	private void Update ()
    {
		if (isButton)
        {
          

        }
        else
        {
            if (leftjoystick)
            {
                Vector3 inputDirection = Vector3.zero;
                inputDirection.x = Input.GetAxis("LeftHorizontal");
                inputDirection.z = Input.GetAxis("LeftVertical");
                thisTransform.position = startPos + inputDirection;
            }
            else if (rightjoystick)
            {
                Vector3 inputDirection = Vector3.zero;
                inputDirection.x = Input.GetAxis("RightHorizontal");
                inputDirection.z = Input.GetAxis("RightVertical");
                thisTransform.position = startPos + inputDirection;
            }
        }
	} 
}
